<!doctype html>
<html lang="pt-br" class="no-js">
<head>	
  <meta charset="utf-8">
  <title>Easy Floater :: Demo</title>
  <meta name="description" content="">
  <meta name="keywords" content="" />
  <meta name="author" content="Bruno Marques"> 
  <link rel="stylesheet" href="css/style.css?v=1">
</head>

<body>
  
  <section id="super">
      
  </section>
   
  <script src="js/toolbox.flashembed.js?v=1"></script>
  <script src="js/easyFloater.js?v=1"></script>
  <script src="js/default.js?v=1"></script>

</body>
</html>